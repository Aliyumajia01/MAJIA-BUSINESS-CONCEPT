
import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";

export default function AdminDashboard() {
  const [logs, setLogs] = useState([]);
  const [error, setError] = useState("");
  const navigate = useNavigate();

  useEffect(() => {
    const token = localStorage.getItem("token");
    if (!token) return navigate("/");

    fetch("/api/admin/logs", {
      headers: { Authorization: `Bearer ${token}` },
    })
      .then((res) => {
        if (!res.ok) throw new Error("Unauthorized or server error");
        return res.json();
      })
      .then(setLogs)
      .catch((err) => setError(err.message));
  }, [navigate]);

  return (
    <div className="p-6 max-w-6xl mx-auto">
      <h1 className="text-2xl font-bold mb-4">Admin - Verification Logs</h1>
      {error && <p className="text-red-500 mb-4">{error}</p>}
      <div className="overflow-auto border rounded">
        <table className="min-w-full text-sm text-left">
          <thead className="bg-gray-100 border-b">
            <tr>
              <th className="p-2">User</th>
              <th className="p-2">NIN</th>
              <th className="p-2">BVN</th>
              <th className="p-2">Date</th>
            </tr>
          </thead>
          <tbody>
            {logs.map((log) => (
              <tr key={log.id} className="border-t hover:bg-gray-50">
                <td className="p-2">{log.user_email}</td>
                <td className="p-2">{log.nin}</td>
                <td className="p-2">{log.bvn}</td>
                <td className="p-2">{new Date(log.created_at).toLocaleString()}</td>
              </tr>
            ))}
          </tbody>
        </table>
        {logs.length === 0 && <p className="p-4">No logs found.</p>}
      </div>
    </div>
  );
}
