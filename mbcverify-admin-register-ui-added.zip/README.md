
# MBCVerify - Full Stack Project

## Frontend (React)
- Located in `client/`
- React + TailwindCSS
- JWT login
- NIN & BVN verification form (protected route)

## Backend (Express)
- Located in `server/`
- JWT Authentication
- `/api/login`
- `/api/verify` connected to Dojah API

## Environment Variables

### Backend (`server/.env`)
```
JWT_SECRET=your_jwt_secret
DOJAH_APP_ID=your_dojah_app_id
DOJAH_SECRET_KEY=your_dojah_secret_key
PORT=5000
```

### Frontend (`client/.env`)
```
VITE_API_BASE_URL=http://localhost:5000
```

## Run Locally
```
cd server
npm install
npm start

cd ../client
npm install
npm run dev
```
